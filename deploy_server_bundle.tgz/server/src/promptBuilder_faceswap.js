/**
 * Prompt builder for faceswap mode
 * 仅替换模板图中指定位置球迷的人脸，保持其余一切不变
 * 零依赖 — 不读 scenes.json / players.json
 */

/**
 * 构建 faceswap 提示词
 *
 * Image 1 = 模板图（底图，保留结构）
 * Image 2 = 球迷照片（人脸来源）
 *
 * @param {Object} [options]
 * @param {string} [options.targetPerson] - 要替换的人物位置描述，如 "the second person from the right"
 * @param {string} [options.userDescription] - 视觉模型生成的外貌描述（可选，增强人脸还原）
 * @returns {{ prompt: string, negative_prompt: string }}
 */
function buildFaceswapPrompt(options = {}) {
  const targetPerson = options.targetPerson || 'the fan (the non-player person)';
  const userDescription = options.userDescription || '';
  const gender = options.gender || 'unknown';
  const compositionNote = options.compositionNote || '';  // 构图锚定，如 "5 persons total: ..."
  const hairstyleNote = options.hairstyleNote || '';      // 精确发型描述（视觉模型专项检测）
  const backgroundNote = options.backgroundNote || '';    // 精确背景描述（防止模型幻觉）

  const appearanceLine = userDescription
    ? `Additional appearance cues from Image 2: ${userDescription}`
    : '';

  // 发型强制锚定（优先级最高，覆盖模型默认行为）
  const hairstyleLockLine = hairstyleNote
    ? `HAIRSTYLE EXACT MATCH (CRITICAL — override all defaults): The person in Image 2 has: ${hairstyleNote}. Reproduce this hairstyle EXACTLY in the result. Do NOT substitute with any other style. IMPORTANT: If a fringe or bangs is described, reproduce it as NATURAL and SOFT with individual hair strands visible and natural movement — do NOT generate a precise uniform straight-across bowl-cut fringe. A "natural soft fringe" must look organic, NOT like a helmet or mushroom cut.`
    : '';

  // 性别锁定（防止 Seedream 生成错误性别外貌）
  const genderLockLine = gender === 'male'
    ? 'GENDER LOCK (MANDATORY): The replaced person is MALE. Reproduce MALE facial structure, MALE hairstyle, and MALE appearance from Image 2 ONLY. Do NOT generate feminine face shape, feminine hairstyle, feminine lips, soft feminine facial contours, or any female facial features — even if the male has soft or youthful features.'
    : gender === 'female'
    ? 'GENDER LOCK (MANDATORY): The replaced person is FEMALE. Reproduce FEMALE facial structure and FEMALE appearance from Image 2 ONLY. Do NOT generate masculine facial features.'
    : '';

  const bodyRuleLine = gender === 'male'
    ? [
        '- CRITICAL HEIGHT RULE: The target fan must stand at the EXACT SAME HEAD-TO-TOE HEIGHT as the adjacent players.',
        '  - His head top must reach the same level as the players\' head tops.',
        '  - Eye level, shoulder level, waist level, knee level, and feet level must all match the players.',
        '  - If the template fan appears shorter or has a female/child body, OVERRIDE it completely — redraw the fan with full adult male proportions matching the surrounding players.',
        '  - The fan is a normal-height adult male. Make him the same height as the other men in the photo.',
        '  - Do NOT make the fan shorter, smaller, stockier, compressed, or childlike under any circumstances.',
      ].join('\n')
    : gender === 'female'
      ? '- Keep full adult proportions for the target person. Do not make the target person childlike or unusually short.'
      : '- Keep full adult proportions for the target person.';

  const heightPreamble = '';

  const prompt = [
    heightPreamble,
    'Photorealistic group photo. Identity-preserving head-swap edit.',
    '',
    'Image 1 is the source template group photo — reproduce it with maximum fidelity.',
    `Image 2 is the identity reference — replace ONLY ${targetPerson} with the SAME PERSON as Image 2.`,
    appearanceLine,
    hairstyleLockLine,
    '',
    'Critical identity rules:',
    `- ${targetPerson} must be clearly identifiable as the exact same person from Image 2.`,
    `- Preserve the identity from Image 2: facial structure, face width, jawline, eye shape, eye openness, nose, lips, skin tone, hairline, hairstyle, hair length, glasses, and age presentation.`,
    '- Replace the entire visible head identity of the target person, not just the inner face area.',
    '- HAIRSTYLE OVERRIDE (CRITICAL): The hairstyle from Image 2 COMPLETELY overrides the hairstyle in Image 1. Reproduce the exact hair from Image 2: silhouette, volume, hairline shape, fringe length and shape, parting direction (or absence of parting), and texture.',
    '- If Image 2 shows NO obvious fringe/bangs (hair does not cover the forehead in a straight line), do NOT generate a straight blunt fringe or bowl-cut fringe. The forehead exposure must match Image 2.',
    '- If Image 2 shows a NATURAL SOFT fringe (hair loosely touches forehead with visible texture and individual strands — NOT a uniform horizontal cut), reproduce it as a natural soft fringe with movement and texture. Do NOT harden it into a precise straight-across bowl-cut line.',
    '- If Image 2 shows NO clear center-part or side-part, do NOT add a center-part or side-part. Generate hair with no defined parting, naturally falling.',
    '- Do not default to any "generic Asian male" hairstyle (bowl cut, blunt straight fringe, neat center-parted cap) — reproduce ONLY what is actually visible in Image 2.',
    gender === 'male'
      ? '- MALE HAIRSTYLE ANTI-BOWL-CUT (MANDATORY): Do NOT generate a bowl cut, mushroom cut, or any hairstyle where hair is uniformly cut in a straight horizontal line across the entire forehead. This is a photorealistic face swap — the hairstyle must come from Image 2, not from a stereotype. If Image 2 shows the forehead exposed (no fringe), keep the forehead exposed. If Image 2 shows some natural hair touching the forehead, make it look natural with visible individual strands and movement — never a helmet-shaped uniform cap.'
      : '',
    genderLockLine,
    '- Do not beautify, feminize, masculinize, cartoonize, or generate a random similar-looking person.',
    '- If Image 2 shows glasses, keep the same glasses. If Image 2 does not show glasses, do not add glasses.',
    '- If Image 1 conflicts with Image 2, follow Image 2 for the target person head and face, but keep the body, pose, and clothing from Image 1.',
    bodyRuleLine,
    '',
    'Strict preservation rules for the rest of the image:',
    '- All players\' faces, expressions, and appearances: IDENTICAL to Image 1.',
    '- All jerseys, numbers, badges: IDENTICAL to Image 1.',
    '- All body poses and positions: IDENTICAL to Image 1.',
    '- Background, lighting, shadows, colors: IDENTICAL to Image 1.',
    backgroundNote
      ? `- BACKGROUND LOCK: ${backgroundNote} — reproduce background EXACTLY as in Image 1, do NOT add, remove, or alter any logos or signs.`
      : '- Background brand logos and text must remain sharp and clearly readable, spelled exactly as shown in Image 1.',
    '- Keep the original camera framing and group composition from Image 1.',
    compositionNote ? `- COMPOSITION LOCK: ${compositionNote} — do NOT drop, add, or merge any person.` : '',
    '- HEAD SIZE (CRITICAL): The replaced head must be the EXACT SAME SIZE as the original head in Image 1 at that position. Do NOT enlarge, shrink, or rescale the head. The head-to-body ratio, head-to-shoulder ratio, and head size relative to other people in the image must all be IDENTICAL to Image 1. Only the face identity changes — the head dimensions do not change.',
    `- Replace only ${targetPerson}'s head/face identity to match Image 2.`,
    '',
    '8K quality, sharp faces, photorealistic.',
  ].filter(Boolean).join('\n');

  const negative_prompt = [
    'changed background, altered stadium, different lighting, modified jersey, wrong jersey number,',
    'altered player face, changed player expression, different player pose, extra people, missing people,',
    'blurry face, distorted face, deformed face, merged faces, cartoon, illustration,',
    'low quality, watermark, text overlay, wrong skin tone on players, wrong hairstyle, wrong hair length,',
    'wrong hairline, wrong fringe, wrong bangs, bowl cut, blunt bowl fringe, straight across fringe, center parted hair, middle part, neat cap-like haircut, generic asian bowl cut, stereotyped asian hairstyle, flat uniform fringe, overly neat hair,',
    'missing glasses, wrong glasses, feminine face when reference is masculine, masculine face when reference is feminine,',
    'shorter body, small body, child proportions, short legs, fan shorter than players,',
    'different height fan, mismatched height, fan at different eye level, fan head lower than players,',
    'oversized head, enlarged head, big head, disproportionate head, head larger than original, head bigger than body,',
    'missing person, only 4 people, dropped character, merged characters, extra person,',
    'blurry logo, unreadable logo, distorted logo, broken text, warped sign, soft background signage, misspelled logo, wrong spelling, hallucinated logo, extra circular logo, FC Bayern circular emblem in background, added stadium logos not in original,',
    'beautified face, childlike face, doll face, generic asian face, identity drift',
  ].join(' ');

  // relay 模式精简版（token 受限，~800 字符）
  const compactPrompt = [
    'Photorealistic group photo. Face-swap edit.',
    `Image 1 = template. Image 2 = face reference.`,
    `Replace ONLY ${targetPerson} with the person from Image 2.`,
    appearanceLine,
    `Identity: face shape, eyes, nose, lips, skin tone, hair from Image 2.`,
    `Hairstyle from Image 2 overrides Image 1 completely.`,
    bodyRuleLine,
    `All players, jerseys, background, logos: IDENTICAL to Image 1.`,
    `8K, photorealistic.`,
  ].filter(Boolean).join(' ');

  return { prompt, negative_prompt, compactPrompt };
}

module.exports = { buildFaceswapPrompt };
